package com.example.gutenberg_blocks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
